1. INPUT:   copy image file n here
2. PROCESS: drag-and-drop n on 9To565.bat
3. OUTPUT:  n.c

Please note that:
n is image file name
n.c is RGB565 data