1. INPUT:   copy video file here
2. PROCESS: drag-and-drop this video file on 1.bat
3. OUTPUT:  n_1.avi

Please note that:
n is video file name
this output file is a AVI data and its format is MJPEG with rotated
0.bat – Rotate by 90 degrees counter-clockwise and flip vertically. This is the default.
1.bat – Rotate by 90 degrees clockwise.
2.bat – Rotate by 90 degrees counter-clockwise.
3.bat – Rotate by 90 degrees clockwise and flip vertically.